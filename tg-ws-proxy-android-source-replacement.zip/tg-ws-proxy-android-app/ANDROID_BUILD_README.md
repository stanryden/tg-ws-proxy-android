# TG WS Proxy — standalone Android wrapper

This is a starter Android Studio project which embeds the existing Python proxy core using Chaquopy. Termux is not required at runtime.

## Status
This is source code, **not a prebuilt or tested APK**. The Android SDK/Gradle environment was unavailable in the preparation environment. Run the GitHub Actions workflow to compile it, then test on a physical device.

## Add to the repository
Extract these files into the root of `stanryden/tg-ws-proxy-android`, preserving paths. Keep the existing `proxy/tg_ws_proxy.py`.

The `.github/workflows/build-android.yml` workflow builds a debug APK and uploads `tg-ws-proxy-debug-apk` as a GitHub Actions artifact.

## Install and configure
1. Open TG WS Proxy and tap **Запустить прокси**.
2. In Telegram: Settings → Data and Storage → Proxy Settings → Add Proxy.
3. Choose SOCKS5, host `127.0.0.1`, port `1080`, no username/password.
4. Keep the persistent service notification active.

## Security and validation warnings
- The upstream proxy core disables TLS certificate validation. The Android build workflow removes those overrides from the Android copy so the system CA and hostname checks remain enabled. This needs runtime verification against Telegram WebSocket endpoints.
- Review the destination-IP routing and TCP fallback behavior.
- Workflow output is a debug-signed APK, not a release-signed APK.
- No device/runtime test has been performed. Verify start/stop, background behavior, Android 13+ notifications, and Telegram connectivity.
- Configured ABIs: `arm64-v8a` and `x86_64`; 32-bit-only devices are not supported.


## Stability patch (2026-10-12)

This build buffers incomplete MTProto abridged frames across TCP reads, sends only complete WebSocket frames, and reports service status only after the local SOCKS5 server has bound its port. The UI and ongoing notification poll the real bridge state. These changes need runtime testing on-device; a successful CI build alone does not prove Telegram compatibility.
