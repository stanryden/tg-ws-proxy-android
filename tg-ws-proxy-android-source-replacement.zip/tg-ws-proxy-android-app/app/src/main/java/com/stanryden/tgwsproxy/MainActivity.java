package com.stanryden.tgwsproxy;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable statusPoll = new Runnable() {
        @Override public void run() {
            if (status != null) status.setText("Статус: " + readableStatus(ProxyService.currentStatus));
            handler.postDelayed(this, 700);
        }
    };

    private String readableStatus(String value) {
        if (value == null || "stopped".equals(value)) return "остановлен";
        if ("starting".equals(value)) return "запускается…";
        if ("running".equals(value)) return "работает";
        if ("stopping".equals(value)) return "останавливается…";
        if (value.startsWith("error:")) return "ошибка — " + value.substring(6).trim();
        return value;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
        }
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 48, 36, 36);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("TG WS Proxy");
        title.setTextSize(28);
        layout.addView(title);
        TextView info = new TextView(this);
        info.setText("Локальный SOCKS5 для Telegram\nАдрес: 127.0.0.1\nПорт: 1080");
        info.setTextSize(17);
        info.setPadding(0, 24, 0, 24);
        layout.addView(info);
        status = new TextView(this);
        status.setText("Статус: остановлен");
        status.setTextSize(16);
        status.setPadding(0, 12, 0, 24);
        layout.addView(status);
        Button start = new Button(this);
        start.setText("Запустить прокси");
        start.setOnClickListener(v -> {
            Intent i = new Intent(this, ProxyService.class).setAction(ProxyService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            status.setText("Статус: запускается…");
        });
        layout.addView(start);
        Button stop = new Button(this);
        stop.setText("Остановить прокси");
        stop.setOnClickListener(v -> {
            startService(new Intent(this, ProxyService.class).setAction(ProxyService.ACTION_STOP));
            status.setText("Статус: остановлен");
        });
        layout.addView(stop);
        TextView note = new TextView(this);
        note.setText("После запуска добавьте в Telegram прокси SOCKS5: 127.0.0.1:1080. Оставьте уведомление службы активным.");
        note.setPadding(0, 28, 0, 0);
        layout.addView(note);
        setContentView(layout);
    }

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(statusPoll);
        handler.post(statusPoll);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(statusPoll);
        super.onPause();
    }
}
