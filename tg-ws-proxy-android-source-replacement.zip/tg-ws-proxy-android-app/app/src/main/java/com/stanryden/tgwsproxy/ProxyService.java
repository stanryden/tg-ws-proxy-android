package com.stanryden.tgwsproxy;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

public class ProxyService extends Service {
    public static final String ACTION_START = "com.stanryden.tgwsproxy.START";
    public static final String ACTION_STOP = "com.stanryden.tgwsproxy.STOP";
    private static final String CHANNEL = "tgwsproxy_status";
    private static final int NOTIFICATION_ID = 1080;
    public static volatile String currentStatus = "stopped";
    private boolean pythonInitialized = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String lastNotificationText = "";

    private final Runnable statusPoll = new Runnable() {
        @Override public void run() {
            refreshStatus();
            if (!"stopped".equals(currentStatus)) handler.postDelayed(this, 700);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "TG WS Proxy", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            handler.removeCallbacks(statusPoll);
            stopProxy();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(NOTIFICATION_ID, notification("Прокси запускается"));
        try {
            if (!Python.isStarted()) Python.start(new com.chaquo.python.android.AndroidPlatform(this));
            pythonInitialized = true;
            PyObject bridge = Python.getInstance().getModule("android_bridge");
            bridge.callAttr("start_proxy");
            currentStatus = "starting";
            handler.removeCallbacks(statusPoll);
            handler.post(statusPoll);
        } catch (Exception e) {
            currentStatus = "error: " + e.getClass().getSimpleName();
            updateNotification("Ошибка запуска: " + e.getClass().getSimpleName());
        }
        return START_NOT_STICKY;
    }

    private void refreshStatus() {
        String state;
        try {
            if (!Python.isStarted()) state = "stopped";
            else state = Python.getInstance().getModule("android_bridge").callAttr("get_status").toString();
        } catch (Exception e) {
            state = "error: " + e.getClass().getSimpleName();
        }
        currentStatus = state;
        String text;
        if ("running".equals(state)) text = "Прокси работает: 127.0.0.1:1080";
        else if ("starting".equals(state)) text = "Прокси запускается…";
        else if ("stopping".equals(state)) text = "Прокси останавливается…";
        else if ("stopped".equals(state)) text = "Прокси остановлен";
        else text = "Ошибка прокси: " + state.replace("error: ", "");
        updateNotification(text);
    }

    private void stopProxy() {
        try {
            if (Python.isStarted()) Python.getInstance().getModule("android_bridge").callAttr("stop_proxy");
        } catch (Exception ignored) {}
        currentStatus = "stopped";
        pythonInitialized = false;
    }

    private Notification notification(String text) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setContentTitle("TG WS Proxy").setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_upload_done).setOngoing(true).build();
    }

    private void updateNotification(String text) {
        if (text.equals(lastNotificationText)) return;
        lastNotificationText = text;
        getSystemService(NotificationManager.class).notify(NOTIFICATION_ID, notification(text));
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(statusPoll);
        if (pythonInitialized) stopProxy();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
