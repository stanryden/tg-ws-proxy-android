# Android lifecycle/status bridge for the existing Telegram WS proxy.
import asyncio
import logging
import threading
import time
import proxy.tg_ws_proxy as core

_log = logging.getLogger("tgwsproxy.android")
_thread = None
_monitor_thread = None
_loop = None
_stop_event = None
_lock = threading.RLock()
_status = "stopped"
_error = ""
_stopping = False
DEFAULT_DC = ["2:149.154.167.220", "4:149.154.167.220"]


def _set_status(state, error=""):
    global _status, _error
    with _lock:
        _status = state
        _error = error or ""


def get_status():
    """Return a short status string for the Android service/UI."""
    with _lock:
        if _status == "error":
            return "error: " + (_error or "неизвестная ошибка")
        return _status


def _worker(port, dc_opt):
    global _loop, _stop_event
    loop = asyncio.new_event_loop()
    with _lock:
        _loop = loop
        _stop_event = asyncio.Event()
        stop_event = _stop_event
    asyncio.set_event_loop(loop)
    try:
        loop.run_until_complete(core._run(port, dc_opt, stop_event=stop_event, host="127.0.0.1"))
        with _lock:
            stopping = _stopping
            state = _status
        if not stopping and state != "error":
            _set_status("error", "сервер прокси неожиданно завершился")
    except Exception as exc:
        _log.exception("Proxy worker stopped unexpectedly")
        with _lock:
            stopping = _stopping
        if not stopping:
            _set_status("error", f"{type(exc).__name__}: {exc}")
    finally:
        try:
            loop.close()
        except Exception:
            pass
        with _lock:
            _loop = None
            _stop_event = None
            stopping = _stopping
            state = _status
        if not stopping and state in ("starting", "running"):
            _set_status("error", "сервер прокси остановился")


def _watch_ready(worker, timeout=12.0):
    """Wait until asyncio.start_server has actually bound the SOCKS port."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        with _lock:
            state = _status
            stopping = _stopping
        if stopping or state == "error":
            return
        if core._server_instance is not None:
            _set_status("running")
            return
        if not worker.is_alive():
            with _lock:
                state = _status
            if state == "starting":
                _set_status("error", "сервер завершился до открытия порта")
            return
        time.sleep(0.1)
    with _lock:
        state = _status
    if state == "starting":
        _set_status("error", "тайм-аут запуска SOCKS5-сервера")


def start_proxy(port=1080):
    global _thread, _monitor_thread, _stopping
    with _lock:
        if _thread is not None and _thread.is_alive():
            return get_status()
        _stopping = False
        _set_status("starting")
        dc_opt = core.parse_dc_ip_list(DEFAULT_DC)
        _thread = threading.Thread(target=_worker, args=(int(port), dc_opt), daemon=True)
        _thread.start()
        _monitor_thread = threading.Thread(target=_watch_ready, args=(_thread,), daemon=True)
        _monitor_thread.start()
    return "starting"


def stop_proxy():
    global _loop, _stop_event, _thread, _stopping
    with _lock:
        _stopping = True
        loop = _loop
        stop_event = _stop_event
        worker = _thread
    _set_status("stopping")
    if loop is not None and stop_event is not None:
        try:
            loop.call_soon_threadsafe(stop_event.set)
        except RuntimeError:
            pass
    if worker is not None:
        worker.join(timeout=4)
    with _lock:
        _thread = None
        _loop = None
        _stop_event = None
    _set_status("stopped")
    with _lock:
        _stopping = False
    return "stopped"
