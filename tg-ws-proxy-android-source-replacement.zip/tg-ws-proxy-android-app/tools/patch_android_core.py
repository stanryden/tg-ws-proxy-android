from pathlib import Path
import re

path = Path("app/src/main/python/proxy/tg_ws_proxy.py")
source = path.read_text(encoding="utf-8")
# Restore certificate and hostname verification in the Android build.
for line in ("_ssl_ctx.check_hostname = False", "_ssl_ctx.verify_mode = ssl.CERT_NONE"):
    if line not in source:
        raise SystemExit(f"Expected insecure TLS override not found: {line}")
    source = source.replace(line + "\n", "")

# TCP reads are arbitrary chunks, not MTProto message boundaries. Keep both
# decrypted bytes and their corresponding ciphertext until each full frame arrives.
new_splitter = r'''class _MsgSplitter:
    """Buffer and split complete MTProto abridged frames across TCP reads."""
    MAX_FRAME_BYTES = 16 * 1024 * 1024

    def __init__(self, init_data: bytes):
        key_raw = bytes(init_data[8:40])
        iv = bytes(init_data[40:56])
        cipher = Cipher(algorithms.AES(key_raw), modes.CTR(iv))
        self._dec = cipher.encryptor()
        self._dec.update(b"\x00" * 64)  # skip obfuscated init packet
        self._pending_plain = bytearray()
        self._pending_cipher = bytearray()

    def split(self, chunk: bytes) -> List[bytes]:
        """Return only complete ciphertext frames; retain any incomplete tail."""
        if not chunk:
            return []
        plain = self._dec.update(chunk)
        self._pending_plain.extend(plain)
        self._pending_cipher.extend(chunk)
        parts = []
        pos = 0
        available = len(self._pending_plain)
        while pos < available:
            first = self._pending_plain[pos]
            if first == 0x7f:
                if available - pos < 4:
                    break
                words = int.from_bytes(self._pending_plain[pos + 1:pos + 4], "little")
                header_len = 4
            else:
                words = first
                header_len = 1
            if words <= 0:
                raise ValueError("invalid zero-length MTProto abridged frame")
            body_len = words * 4
            frame_len = header_len + body_len
            if frame_len > self.MAX_FRAME_BYTES:
                raise ValueError("MTProto frame exceeds safety limit")
            if available - pos < frame_len:
                break
            end = pos + frame_len
            parts.append(bytes(self._pending_cipher[pos:end]))
            pos = end
        if pos:
            del self._pending_plain[:pos]
            del self._pending_cipher[:pos]
        return parts
'''
source, n = re.subn(r'class _MsgSplitter:\n.*?(?=\ndef _ws_domains\()', new_splitter, source, count=1, flags=re.S)
if n != 1:
    raise SystemExit("Could not find _MsgSplitter class to patch")
old = '''                    parts = splitter.split(chunk)
                    if len(parts) > 1:
                        await ws.send_batch(parts)
                    else:
                        await ws.send(parts[0])'''
new = '''                    parts = splitter.split(chunk)
                    if len(parts) > 1:
                        await ws.send_batch(parts)
                    elif len(parts) == 1:
                        await ws.send(parts[0])'''
if old not in source:
    raise SystemExit("Could not find splitter send block to patch")
source = source.replace(old, new, 1)
path.write_text(source, encoding="utf-8")
print("Android core patched: TLS verification enabled; MTProto frame buffering enabled.")
