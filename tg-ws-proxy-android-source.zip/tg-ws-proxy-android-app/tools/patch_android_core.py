from pathlib import Path

path = Path("app/src/main/python/proxy/tg_ws_proxy.py")
source = path.read_text(encoding="utf-8")
unsafe = [
    "_ssl_ctx.check_hostname = False",
    "_ssl_ctx.verify_mode = ssl.CERT_NONE",
]
for line in unsafe:
    if line not in source:
        raise SystemExit(f"Expected insecure TLS override not found: {line}")
    source = source.replace(line + "\n", "")
path.write_text(source, encoding="utf-8")
print("Android copy: TLS certificate and hostname validation restored.")
