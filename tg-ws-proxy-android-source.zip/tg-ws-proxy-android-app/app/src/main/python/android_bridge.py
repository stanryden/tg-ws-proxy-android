# Bridge between Android foreground service and the existing proxy core.
import asyncio
import logging
import threading
import proxy.tg_ws_proxy as core

_log = logging.getLogger("tgwsproxy.android")
_thread = None
_loop = None
_stop_event = None
DEFAULT_DC = ["2:149.154.167.220", "4:149.154.167.220"]

def _worker(port, dc_opt):
    global _loop, _stop_event
    _loop = asyncio.new_event_loop()
    asyncio.set_event_loop(_loop)
    _stop_event = asyncio.Event()
    try:
        _loop.run_until_complete(core._run(port, dc_opt, stop_event=_stop_event, host="127.0.0.1"))
    except Exception:
        _log.exception("Proxy worker stopped unexpectedly")
    finally:
        try:
            _loop.close()
        except Exception:
            pass
        _loop = None
        _stop_event = None

def start_proxy(port=1080):
    global _thread
    if _thread is not None and _thread.is_alive():
        return "already_running"
    dc_opt = core.parse_dc_ip_list(DEFAULT_DC)
    _thread = threading.Thread(target=_worker, args=(int(port), dc_opt), daemon=True)
    _thread.start()
    return "starting"

def stop_proxy():
    global _loop, _stop_event, _thread
    if _loop is not None and _stop_event is not None:
        _loop.call_soon_threadsafe(_stop_event.set)
    if _thread is not None:
        _thread.join(timeout=3)
    _thread = None
    return "stopped"
